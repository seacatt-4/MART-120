onEvent("startbutton", "click", function( ) {
  setScreen("DressUpScreen");
  setProperty("shoes2", "hidden", true);
  setProperty("shoes3", "hidden", true);
  setProperty("shoes4", "hidden", true);
  setProperty("bottoms2", "hidden", true);
  setProperty("bottoms3", "hidden", true);
  setProperty("bottoms4", "hidden", true);
  setProperty("tops2", "hidden", true);
  setProperty("tops3", "hidden", true);
  setProperty("tops4", "hidden", true);
  setProperty("face2", "hidden", true);
  setProperty("face3", "hidden", true);
  setProperty("face4", "hidden", true);
  setProperty("hair2", "hidden", true);
  setProperty("hair3", "hidden", true);
  setProperty("hair4", "hidden", true);
  setProperty("messageResultsfired", "hidden", true);
  setProperty("messageResultscozy", "hidden", true);
  setProperty("messageResultsclassy", "hidden", true);
  setProperty("messageResultsbold", "hidden", true);
  setProperty("buttonRestart", "hidden", true);
});
var hair = ["1","2","3","4"];
var currenthair = randomNumber(1);
console.log("Chose  " + hair[currenthair]);
var face = ["1","2", "3", "4"];
var currentface = randomNumber(1);
console.log("Chose  " + face[currentface]);
var top = ["tops1","tops2", "tops3", "tops4"];
var currenttop = randomNumber(1);
console.log("Chose  " + top[currenttop]);
var bottoms = ["bottoms1","bottoms2","bottoms3","bottoms4"];
var currentbottoms = randomNumber(1);
console.log("Chose  " + bottoms[currentbottoms]);
var shoes = ["shoes1","shoes2","shoes3","shoes4"];
var currentshoes = randomNumber(1);
console.log("Chose  " + shoes[currentshoes]);
var points = 0;
var score = ["-5","-4","-3","-2","-1","0","1","2","3","4","5"];
var currentScore = randomNumber(1);
console.log("Score of" + score[currentScore]);
var item = ["waterbottle!","lucky pencil!","scissors!","lunchbox!"];
var currentitem = item;
onEvent("HairButton", "click", function() {
	console.log("HairButton Clicked! " + hair[currenthair]);
	setProperty("hair1", "hidden", true);
	if (currenthair == 0) {
	  setProperty("hair2", "hidden", false);
	  setProperty("hair1", "hidden", true);
	  currenthair = 1;
	} else {
	  if (currenthair == 1) {
	    setProperty("hair3", "hidden", false);
	    setProperty("hair2", "hidden", true);
	    currenthair = 2;
	  } else {
	    if (currenthair == 2) {
	      setProperty("hair4", "hidden", false);
	      setProperty("hair3", "hidden", true);
	      currenthair = 3;
	    } else {
	      if (currenthair == 3) {
	        setProperty("hair1", "hidden", false);
	        setProperty("hair4", "hidden", true);
	        currenthair = 0;
	      }
	    }
	  }
	}
});
onEvent("FaceButton", "click", function() {
	console.log("FaceButton Clicked! " + face[currentface]);
	setProperty("face1", "hidden", true);
	if (currentface == 0) {
	  setProperty("face2", "hidden", false);
	  setProperty("face1", "hidden", true);
	  currentface = 1;
	} else {
	  if (currentface == 1) {
	    setProperty("face3", "hidden", false);
	    setProperty("face2", "hidden", true);
	    currentface = 2;
	  } else {
	    if (currentface == 2) {
	      setProperty("face4", "hidden", false);
	      setProperty("face3", "hidden", true);
	      currentface = 3;
	    } else {
	      if (currentface == 3) {
	        setProperty("face1", "hidden", false);
	        setProperty("face4", "hidden", true);
	        currentface = 0;
	      }
	    }
	  }
	}
});
onEvent("TopsButton", "click", function() {
	console.log("TopsButton Clicked! " + top[currenttop]);
	setProperty("tops1", "hidden", true);
	if (currenttop == 0) {
	  setProperty("tops2", "hidden", false);
	  setProperty("tops1", "hidden", true);
	  currenttop = 1;
	} else {
	  if (currenttop == 1) {
	    setProperty("tops3", "hidden", false);
	    setProperty("tops2", "hidden", true);
	    currenttop = 2;
	  } else {
	    if (currenttop == 2) {
	      setProperty("tops4", "hidden", false);
	      setProperty("tops3", "hidden", true);
	      currenttop = 3;
	    } else {
	      if (currenttop == 3) {
	        setProperty("tops1", "hidden", false);
	        setProperty("tops4", "hidden", true);
	        currenttop = 0;
	      }
	    }
	  }
	}
});
onEvent("BottomsButton", "click", function() {
	console.log("BottomsButton Clicked! " + bottoms[currentbottoms]);
	setProperty("bottoms1", "hidden", true);
	if (currentbottoms == 0) {
	  setProperty("bottoms2", "hidden", false);
	  setProperty("bottoms1", "hidden", true);
	  currentbottoms = 1;
	} else {
	  if (currentbottoms == 1) {
	    setProperty("bottoms3", "hidden", false);
	    setProperty("bottoms2", "hidden", true);
	    currentbottoms = 2;
	  } else {
	    if (currentbottoms == 2) {
	      setProperty("bottoms4", "hidden", false);
	      setProperty("bottoms3", "hidden", true);
	      currentbottoms = 3;
	    } else {
	      if (currentbottoms == 3) {
	        setProperty("bottoms1", "hidden", false);
	        setProperty("bottoms4", "hidden", true);
	        currentbottoms = 0;
	      }
	    }
	  }
	}
});
onEvent("ShoesButton", "click", function() {
	console.log("ShoesButton Clicked! " + shoes[currentshoes]);
	setProperty("shoes1", "hidden", true);
	if (currentshoes == 0) {
	  setProperty("shoes2", "hidden", false);
	  setProperty("shoes1", "hidden", true);
	  currentshoes = 1;
	} else {
	  if (currentshoes == 1) {
	    setProperty("shoes3", "hidden", false);
	    setProperty("shoes2", "hidden", true);
	    currentshoes = 2;
	  } else {
	    if (currentshoes == 2) {
	      setProperty("shoes4", "hidden", false);
	      setProperty("shoes3", "hidden", true);
	      currentshoes = 3;
	    } else {
	      if (currentshoes == 3) {
	        setProperty("shoes1", "hidden", false);
	        setProperty("shoes4", "hidden", true);
	        currentshoes = 0;
	      }
	    }
	  }
	}
});
onEvent("doneButton", "click", function( ) {
  score = 0;
  points = 1;
  console.log("Score of "+score);
  setScreen("itemScreen");
  setProperty("selectButton", "hidden", true);
});
onEvent("dropdownItem", "change", function( ) {
  setProperty("selectButton", "hidden", false);
  item = getText("dropdownItem");
  console.log("Chose item " + item[currentitem]);
});
onEvent("selectButton", "click", function( ) {
  setScreen("schoolScreen");
});
onEvent("classButton", "click", function( ) {
  setScreen("class1");
  setProperty("submit1Button", "hidden", true);
      });
onEvent("dropdown1", "change", function( ) {
  if (getText("dropdown1") == "5") {
    points = 1;
    currentScore = score+points;
  }
  console.log("Score of " + currentScore);
  setProperty("submit1Button", "hidden", false);
      });
onEvent("submit1Button", "click", function( ) {
  setScreen("class2");
  setProperty("submit2Button", "hidden", true);
        });
onEvent("dropdown2", "change", function( ) {
  if (getText("dropdown2") == "ponderosa pine") {
    points = 1;
    score = currentScore+points;
  }
  currentScore = score;
  console.log("Score of " + currentScore);
  setProperty("submit2Button", "hidden", false);
      });
onEvent("submit2Button", "click", function( ) {
  setScreen("class3");
  setProperty("submit3Button", "hidden", true);
        });
onEvent("dropdown3", "change", function( ) {
  if (getText("dropdown3") == "green") {
    points = 1;
  }
  currentScore = score+points;
  console.log("Score of " + currentScore);
  setProperty("submit3Button", "hidden", false);
          });
onEvent("submit3Button", "click", function( ) {
  setScreen("zombieClass");
  setProperty("buttonClasszombie", "hidden", true);
  setProperty("messageClassfail", "hidden", true);
  setProperty("messageClasshide", "hidden", true);
  setProperty("messageClasswin", "hidden", true);
  setProperty("buttonContinuezombie", "hidden", true);
            });
onEvent("dropZombie1", "change", function( ) {
  setProperty("buttonClasszombie", "hidden", false);
                });
onEvent("buttonClasszombie", "click", function( ) {
  if (getText("dropZombie1") == "Window!") {
    setScreen("zombieWindow");
    setProperty("messageWindowfail", "hidden", true);
    setProperty("messageWindowwin", "hidden", true);
    setProperty("buttonContinuewindow", "hidden", true);
    score = currentScore + points;
  } else {
    if (getText("dropZombie1") == "Hallway!") {
      setScreen("zombieHallway");
      setProperty("messageHallwayfail", "hidden", true);
      setProperty("messageHallwaywin", "hidden", true);
      setProperty("buttonContinuehallway", "hidden", true);
      setProperty("messageHallwayhide", "hidden", true);
      score = currentScore+points;
    } else {
      if (getText("dropZombie1") == "Hide!") {
        setProperty("dropZombie1", "hidden", true);
        setProperty("messageZombie1", "hidden", true);
        setProperty("messageClasshide", "hidden", false);
        setProperty("buttonClasszombie", "hidden", true);
        setProperty("buttonContinuezombie", "hidden", false);
        score = currentScore-points;
      } else {
        if (getText("dropZombie1") == "Use Accessory!") {
          setProperty("dropZombie1", "hidden", true);
          setProperty("messageZombie1", "hidden", true);
          setProperty("buttonContinuezombie", "hidden", false);
          setProperty("buttonClasszombie", "hidden", true);
          if (getText("dropdownItem") == "Scissors!") {
            setProperty("messageClasswin", "hidden", false);
            score = currentScore + points;
          } else {
            setProperty("messageClassfail", "hidden", false);
            score = currentScore-points;
          }
        }
      }
    }
  }
  currentScore = score;
  console.log("Score of " + currentScore);
});
onEvent("buttonClasszombie", "click", function( ) {
  if (getText("dropdown1")=="Hallway!") {
    setScreen("zombieHallway");
    setProperty("messageHallwayfail", "hidden", true);
    setProperty("messageHallwaywin", "hidden", true);
    setProperty("buttonContinuehallway", "hidden", true);
    setProperty("messageHallwayhide", "hidden", true);
  } else {
    if (getText("dropdown1")=="Window!") {
      setScreen("zombieWindow");
      setProperty("messageWindowfail", "hidden", true);
      setProperty("messageWindowwin", "hidden", true);
      setProperty("buttonContinuewindow", "hidden", true);
      setProperty("messageWindowhide", "hidden", true);
    }
  }
});
onEvent("buttonContinuezombie", "click", function( ) {
  setScreen("zombieWindow");
  setProperty("messageWindowfail", "hidden", true);
  setProperty("messageWindowwin", "hidden", true);
  setProperty("buttonContinuewindow", "hidden", true);
  setProperty("messageWindowhide", "hidden", true);
});
onEvent("buttonHallway", "click", function( ) {
  setProperty("buttonHallway", "hidden", true);
  setProperty("dropHallway", "hidden", true);
  setProperty("messageHallway", "hidden", true);
  if (getText("dropHallway") == "Street!") {
    setProperty("buttonContinuehallway", "hidden", false);
    setScreen("zombieStreet");
    score = currentScore+points;
  } else {
    if (getText("dropHallway") == "Classroom!") {
      setProperty("buttonContinuehallway", "hidden", false);
      setScreen("zombieClass2");
      score = currentScore-points;
    } else {
      if (getText("dropHallway") == "Hide!") {
        setProperty("messageHallwayhide", "hidden", false);
        setProperty("buttonContinuehallway", "hidden", false);
        score = currentScore-points;
      } else {
        if (getText("dropHallway") == "Use Accessory!") {
          if (getText("dropdownItem") == "Bandaids!") {
            setProperty("messageHallwaywin", "hidden", false);
            setProperty("buttonContinuehallway", "hidden", false);
            score = currentScore+points;
          } else {
            setProperty("messageHallwayfail", "hidden", false);
            setProperty("buttonContinuehallway", "hidden", false);
            score = currentScore-points;
          }
        }
      }
    }
  }
  currentScore = score;
  console.log("Score of " + currentScore);
});
onEvent("buttonContinuehallway", "click", function( ) {
  setScreen("zombieStreet");
});
onEvent("buttonWindow", "click", function() {
  if (getText("dropWindow") == "Street!") {
    setProperty("buttonContinuewindow", "hidden", false);
    setScreen("zombieStreet");
    currentScore = score+points;
  } else {
    if (getText("dropWindow") == "Classroom!") {
      setProperty("buttonContinuewindow", "hidden", false);
      setScreen("zombieClass2");
      currentScore = score-points;
    } else {
      if (getText("dropWindow") == "Hide!") {
        setProperty("dropWindow", "hidden", true);
        setProperty("messageWindow", "hidden", true);
        setProperty("messageWindowhide", "hidden", false);
        setProperty("buttonWindow", "hidden", true);
        setProperty("buttonContinuewindow", "hidden", false);
        currentScore = score-points;
      } else {
        if (getText("dropWindow") == "Use Accessory!") {
          setProperty("dropWindow", "hidden", true);
          setProperty("messageWindow", "hidden", true);
          setProperty("buttonWindow", "hidden", true);
          if (getText("dropdownItem") == "Lunchbox!") {
            setProperty("messageWindowwin", "hidden", false);
            setProperty("buttonContinuewindow", "hidden", false);
            currentScore = score+points;
          } else {
            setProperty("messageWindowfail", "hidden", false);
            setProperty("buttonContinuewindow", "hidden", false);
            currentScore = score-points;
          }
        }
      }
    }
  }
  console.log("Score of " + currentScore);
});
onEvent("buttonContinuewindow", "click", function() {
  setScreen("zombieStreet");
});
onEvent("buttonResults", "click", function( ) {
  console.log("Score of " + currentScore);
  setScreen("DressUpScreen");
  setProperty("resultsFired", "hidden", true);
  setProperty("resultsCozy", "hidden", true);
  setProperty("resultsClassy", "hidden", true);
  setProperty("resultsBold", "hidden", true);
  if (currentScore<=1) {
    setProperty("messageResultsfired", "hidden", false);
  } else {
    if (currentScore==2) {
      setProperty("messageResultsclassy", "hidden", false);
    } else {
      if (currentScore==3) {
        setProperty("messageResultscozy", "hidden", false);
      } else {
        if (currentScore >= 4) {
          setProperty("messageResultsbold", "hidden", false);
        }
      }
    }
  }
  setProperty("buttonRestart", "hidden", false);
  setProperty("doneButton", "hidden", true);
});
onEvent("buttonRestart", "click", function( ) {
  setScreen("TitleScreen");
});
